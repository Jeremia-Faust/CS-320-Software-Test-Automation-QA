package Tests;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;

@SuppressWarnings("deprecation")

class AppointmentServiceTest {

	@Test  
	void testAddAppointment() {
		AppointmentService appointment = new AppointmentService();
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Appointment AppointmentOne = new Appointment ("1111",date,"1234");
		assertEquals(true,appointment.addAppointment(AppointmentOne));
	}
	@Test
	void testAddTaskAppointment() {
		AppointmentService appointment = new AppointmentService();
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Appointment AppointmentOne = new Appointment ("1111",date,"1234");
		assertEquals(true,appointment.addAppointment(AppointmentOne));
		assertEquals(false,appointment.addAppointment(AppointmentOne));
		
	}

	@Test
	void testDeleteAppointment() {
		AppointmentService appointment = new AppointmentService();
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Appointment AppointmentOne = new Appointment ("1111",date,"1234");
		assertEquals(true,appointment.addAppointment(AppointmentOne));
		assertEquals(true,appointment.removeAppointment("1111"));
	}
	@Test
	void testDeleteAppointmentfail() {
		AppointmentService appointment = new AppointmentService();
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Appointment AppointmentOne = new Appointment ("1111",date,"1234");
		assertEquals(true,appointment.addAppointment(AppointmentOne));
		assertEquals(false,appointment.removeAppointment("1234"));
	}

}
