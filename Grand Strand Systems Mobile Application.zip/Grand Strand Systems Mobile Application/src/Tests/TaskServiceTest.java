package Tests;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

public class TaskServiceTest {
	@Test  
	void testAddTask() {
		TaskService taskService = new TaskService();
		Task TaskOne = new Task ("1111","1234","1234");
		assertEquals(true,taskService.addtask(TaskOne));
	}
	@Test
	void testAddTaskFail() {
		TaskService taskService = new TaskService();
		Task taskOne = new Task ("12341","1324","123456");
		assertEquals(true,taskService.addtask(taskOne));
		assertEquals(false,taskService.addtask(taskOne));
		
	}

	@Test
	void testDeleteTask() {
		TaskService taskService = new TaskService();
		Task TaskOne = new Task ("1111","1234","1234");
		assertEquals(true,taskService.addtask(TaskOne));
		assertEquals(true,taskService.removeTask("1111"));
	}
	@Test
	void testDeleteTaskfail() {
		TaskService taskService = new TaskService();
		Task taskOne = new Task ("1234","1234","1234");
		taskService.addtask(taskOne);
		assertEquals(false,taskService.removeTask("1111"));
	}
	
	@Test
	void testUpdateTask() {
		TaskService taskService = new TaskService();
		Task taskOne = new Task ("1111","1234","1234");
		taskService.addtask(taskOne);
		assertEquals(true,taskService.updateTask("1111","4321","4321"));
	}
	@Test
	void testUpdateTaskfail() {
		TaskService taskService = new TaskService();
		Task taskOne = new Task ("1111","1234","1234");
		taskService.addtask(taskOne);
		assertEquals(false,taskService.updateTask(null,"4321",null));
	}
}

