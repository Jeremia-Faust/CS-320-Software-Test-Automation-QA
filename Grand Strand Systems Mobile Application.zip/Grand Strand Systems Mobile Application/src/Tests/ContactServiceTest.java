package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Contact.Contact;
import Contact.ContactService;

class ContactServiceTest {
	
	
	
	@Test  
	void testAddContact() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		assertEquals(true,contactService.addContact(contactOne));
	}
	@Test
	void testAddContactfail() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		assertEquals(true,contactService.addContact(contactOne));
		assertEquals(false,contactService.addContact(contactOne));
	}

	@Test
	void testDeleteContact() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		contactService.addContact(contactOne);
		assertEquals(true,contactService.removeContact("1111"));
	}
	@Test
	void testDeleteContactfail() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		contactService.addContact(contactOne);
		assertEquals(false,contactService.removeContact("1011"));
	}
	
	@Test
	void testUpdateContact() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		contactService.addContact(contactOne);
		assertEquals(true,contactService.updateContact("1111","4321","4321","2345678911","4321"));
	}
	@Test
	void testUpdateContactfail() {
		ContactService contactService = new ContactService();
		Contact contactOne = new Contact ("1111","1234","1234","1234567891", "1234");
		contactService.addContact(contactOne);
		assertEquals(false,contactService.updateContact(null,null,null,null,null));
	}
}
