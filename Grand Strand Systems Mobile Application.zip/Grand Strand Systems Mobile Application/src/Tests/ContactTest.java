package Tests;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Contact.Contact;


class ContactTest {

	@Test //test if all are true
	void testContactClass() {
		Contact contact = new Contact("1234","1234","1234","1234567891","1234");
		assertTrue(contact.getContactId().equals("1234"));
		assertTrue(contact.getFirstName().equals("1234"));
		assertTrue(contact.getLastName().equals("1234"));
		assertTrue(contact.getPhoneNumber().equals("1234567891"));
		assertTrue(contact.getAddress().equals("1234"));
	}
	@Test // test if one is to long
	void testContactIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345678911","1234","1234","1234567891l","1234");
		});
	}
	@Test // test if one is to long
	void testFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","12345678911","1234","1234567891","1234");
		});
	}
	@Test // test if one is to long
	void testLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","12345678911","12345678911","1234");
		});
	}
	@Test // test if one is to long
	void testPhoneNumberToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","1234","12345678911","1234");
		});
	}
	@Test // test if one is to short
	void testPhoneNumberToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","1234","123","1234");
		});
	}
	@Test // test if one is to long
	void testAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","1234","1234567891","12345678911234567891123456789111111111111");
		});
	}
	@Test // test if one is null
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact(null,"1234","1234","1234","1234");
		});
	}
	@Test// test if one is null
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234",null,"1234","1234","1234");
		});
	}
	@Test// test if one is null
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234",null,"1234","1234");
		});
	}
	@Test// test if one is null
	void testPhoneNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","1234",null,"1234");
		});
	}
	@Test// test if one is null
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("1234","1234","1234","1234",null);
		});
	}




}

