package Tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Task.Task;

public class TaskTest {
	@Test //test if all are true
	void testTaskClass() {
		Task task = new Task("1234","1234","1234");
		assertTrue(task.getTaskId().equals("1234"));
		assertTrue(task.getTaskName().equals("1234"));
		assertTrue(task.getTaskDescription().equals("1234"));
		
	}
	@Test // test if one is to long
	void testTaskIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345678911","1234","1234");
		});
	}
	@Test // test if one is to long
	void testTaskNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1234","123456789112345678911","1234");
		});
	}
	@Test // test if one is to long
	void testTaskDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1234","1234","123456789112345678911234567891123456789112345678911");
		});
	}
	
	@Test // test if one is null
	void testTaskIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task(null,"1234","1234");
		});
	}
	@Test// test if one is null
	void testTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1234",null,"1234");
		});
	}
	@Test// test if one is null
	void testtaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1234","1234",null);
		});
	}
	
	
}
