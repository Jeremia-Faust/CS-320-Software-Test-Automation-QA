package Tests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;

import java.sql.Date;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;


@SuppressWarnings("deprecation")

class AppointmentTest {

	
	@Test //test if all are true
	void testAppointmentClass() {
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Appointment appointment = new Appointment("1234", date, "1234");
		assertTrue(appointment.getAppointmentId().equals("1234"));
		assertEquals(date,appointment.getDate());
		assertTrue(appointment.getAppointmentDescription().equals("1234"));
		
	}
	@Test // test if one is to long
	void testAppointmentIDToLong() {
		
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345678911",date,"1234");
		});
	}
	@Test // test if one is to long
	void testAppointmentIDNull() {
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment(null,date,"1234");
		});
	}
	
	
	
	
	@Test // test if one is before date
	void testDateBefore() {
		Date date = new Date(0);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("123456789",date,"1234");
		});
	}
	@Test // test if  one is null
	void testDateNull() {
		//Date date = new Date(2301,Calendar.OCTOBER,20);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345678911",null,"1234");
		});
	}
	@Test // test if one is to long
	void testAppointmentDescriptionToLong() {
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1234",date,"123456789112345678911234567891123456789112345678911");
		});
	}
	@Test // test if one is to long
	void testAppointmentDescriptionNull() {
		Date date = new Date(2301,Calendar.OCTOBER,20);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1234",date,null);
		});
	}
}
