package Contact;

import java.util.ArrayList;

/* I got some help with this part of the project because when i tryed to do the same thing that the video did and what I did in contact.java
 was not working for me. It was suggested that I use boolean  and then i use the assertEquals for the tests based on the return type of the 
 Bool methods 
  
  
 * */

public class ContactService {
   
   private ArrayList<Contact> contacts;

   /* default constructor */
   public ContactService() {
       contacts = new ArrayList<>();
   }

   //adds contact
   public boolean addContact(Contact contact) {
      //this part checks the arraylist to see if the contact exists if it does it change the variable to true
       boolean existingContact = false;
       for (Contact list : contacts) {
           if (list.equals(contact)) {
        	   existingContact = true;
        	   
           }
       }
      // this check the variable if true or not. If true we return false and if false we add contact and return true.
       if (!existingContact ) {
           contacts.add(contact);
           return true;
           
       } 
       else {
           return false;
       }
   }

  //the method delete the contact
   public boolean removeContact(String contactID) {
       // this checks if the  contact is in the list if it is we remove the contact and return true. if the contact is not in list we return false.
	   for (Contact list : contacts) {
           if (list.getContactId().equals(contactID)) {
               contacts.remove(list);
               return true;
           }
       }
       
       return false;
   }

// This method updates the contact
   public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
	// this checks if the  contact is in the list if it is we update the contact and return true. if the contact is not in list we return false.
	   for (Contact list : contacts) {
           if (list.getContactId().equals(contactID)) {
                   list.setFirstName(firstName);
                   list.setLastName(lastName);
                   list.setPhoneNumber(phoneNumber);
                   list.setAddress(address);
               
               return true;
           }
       }
       
       return false;
   }

}