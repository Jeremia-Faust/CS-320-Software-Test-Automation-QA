package Appointment;



import java.util.Date;

public class Appointment {
	String appointmentId;
	String appointmentDescription;
	Date date;
	
	public Appointment(String appointmentId,Date date, String appointmentDescription) {
		
				
		if (appointmentId == null || appointmentId.length()>10 ) {
			throw new IllegalArgumentException("Invalid Appointment Id");
		}
		if (date == null || date.before(new Date()) ) {
			throw new IllegalArgumentException("Invalid Date");
		}
		if (appointmentDescription == null || appointmentDescription.length()>50 ) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}
		
		this.appointmentId = appointmentId;
		this.date = date;
		this.appointmentDescription = appointmentDescription;
		
	}
	

	public String getAppointmentId() {
		return appointmentId;
	}
	public Date getDate() {
		return date;
	}
	public String  getAppointmentDescription() {
		return appointmentDescription;
	}
	

	
	
	@Override
	   public boolean equals(Object object) {
	       if (this == object) {
	          
	       }
	       return true;
	   }

	
}
