package Task;

import java.util.ArrayList;

public class TaskService {
	private ArrayList<Task> tasks;

	   /* default constructor */
	   public TaskService() {
	       tasks = new ArrayList<>();
	   }

	   //adds task
	   public boolean addtask(Task task) {
	      //this part checks the arraylist to see if the contact exists if it does it change the variable to true
	       boolean existingTask = false;
	       for (Task list : tasks) {
	           if (list.equals(task)) {
	        	   existingTask = true;
	           }
	       }
	      // this check the variable if true or not. If true we return false and if false we add contact and return true.
	       if (existingTask == false) {
	           tasks.add(task);
	           return true;
	           
	       } 
	       
	           return false;
	       
	   }

	  //the method delete the task
	   public boolean removeTask(String taskId) {
	       // this checks if the task is in the list if it is we remove the contact and return true. if the task is not in list we return false.
		   for (Task list : tasks) {
	           if (list.getTaskId().equals(taskId)) {
	               tasks.remove(list);
	               return true;
	           }
	       }
	       
	       return false;
	   }

	// This method updates the task
	   public boolean updateTask(String taskId, String taskName, String taskDescription) {
		// this checks if the  contact is in the list if it is we update the contact and return true. if the contact is not in list we return false.
		   for (Task list : tasks) {
	           if (list.getTaskId().equals(taskId)) {
	                   list.setTaskName(taskName);
	                   list.setTaskDescription(taskDescription);
	                   
	               
	               return true;
	           }
	       }
	       
	       return false;
	   }

}
