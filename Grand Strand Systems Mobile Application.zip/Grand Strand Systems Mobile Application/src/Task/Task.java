package Task;

public class Task {
	String taskId;
	String taskName;
	String taskDescription;
	
	
	public Task(String taskId,String taskName,String taskDescription) {
		if (taskId == null || taskId.length()>10 ) {
			throw new IllegalArgumentException("Invalid Task Id");
		}
		if (taskName == null || taskName.length()>20 ) {
			throw new IllegalArgumentException("Invalid Task Name");
		}
		if (taskDescription== null || taskDescription.length()>50 ) {
			throw new IllegalArgumentException("Invalid Task Description");
		}
		
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
		
	}
	public String getTaskId() {
		return taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public String  getTaskDescription() {
		return taskDescription;
	}
	
	public void setTaskName(String taskName) {
		this.taskName = taskName;
		
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
		
	}
	
	//for some reason the add task was not working so I got help they told me That I need to use this override. Once it was added it everything started to work    
	@Override
	   public boolean equals(Object object) {
	       if (this == object) {
	          
	       }
	       return true;
	   }

	

}
